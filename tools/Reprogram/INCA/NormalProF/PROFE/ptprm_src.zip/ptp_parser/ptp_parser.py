"""
A module to parser ptp file
Log:
When       Who           What
2012/5/13  Xu Hui  Fixed bug in get_data_by_address_and_length(Can't take address prefixed with 0 as parameter such as
                   0x00020000)
                   Added split_data_line_into_list
"""

__author__ ="hui.xu2@delphi.com"
__version__="3.0"

class ptp_file:
    """
    ptp file class

    OVERVIEW:
    This class is to parser ptp/s19 file, it knows the format/address/data/checksum of each line in ptp/s19 file

    DATA:
    self.all_lines          - stores all the lines of ptp/s19 file
    self.__line_numbers     - stores the total line numbers of ptp/s19 file
    self.dict_by_address    - stores all the lines by their address as a key of this dictionary

    Method:
    get_line_number()                                -> int
    get_current_line_format(int)                     -> string
    get_current_line_format_by_content(string)       -> string
    get_size_of_line(int)                            -> string
    get_address_of_line(int)                         -> string
    get_address_of_line_by_content(string)           -> string
    get_checksum_of_line(int)                        -> string
    get_data_of_line(int)                            -> string
    get_data_of_line_by_content(string)              -> string
    get_data_no_in_byte(int)                         -> int
    get_data_of_line_as_list(int)                    -> list
    get_data_by_address_and_length(int, int)         -> string
    get_data_by_start_and_end_address(int, int)      -> string
    split_data_line_into_list(string)                -> list

    """
    def __init__(self,filename):
        self.__line_numbers = 0
        self.all_lines = []
        self.dict_by_address = {}

        with open(filename, 'r') as infile:
            for line in infile:
                self.__line_numbers += 1
                self.all_lines.append(line)
                key = self.get_address_of_line_by_content(line)
                if key != 'NO_DATA':
                    key = '0x' + key
                    key = key.lower()
                    value = self.get_data_of_line_by_content(line)
                    self.dict_by_address[key] = value

    def get_total_line_numbers(self):
        """
        get_total_line_numbers() -> int
        return the field __line_numbers
        """
        return self.__line_numbers

    def get_current_line_format_by_content(self, line_contents):
        """
        get_current_line_format_by_content(line_contents) -> string
        Get the format of current line by the line's content, the first line number is ZERO, the line format can be S0 S1 S2 S3 S4 S5 .....
        """
        return line_contents[0:2]

    def get_current_line_format(self,line_no):
        """
        get_current_line_format(line_no) -> string
        Get the format of current line, the first line number is ZERO, the line format can be S0 S1 S2 S3 S4 S5 .....
        """
        return self.all_lines[line_no][0:2]

    def get_size_of_line(self,line_no):
        """
        get_size_of_line(line_no) -> string
        Get the size information of current line accodring to the line format, 
        return NOT_DATA for no data line(S0/S4/S5/S6/S7.....)
        """
        line_format = self.get_current_line_format(line_no)
        if line_format == 'S1' or line_format == 'S2' or line_format == 'S3':
            return self.all_lines[line_no][2:4]
        else:
            return 'NO_DATA'

    def get_address_of_line_by_content(self, line_contents):
        """
        get_address_of_line_by_content(line_contents) -> string
        Get the address information of current line by line contents accodring to the line format, 
        return NOT_DATA for no data line(S0/S4/S5/S6/S7.....)
        """
        line_format = self.get_current_line_format_by_content(line_contents)
        if line_format == 'S1':
            return line_contents[4:8]
        elif line_format == 'S2':
            return line_contents[4:10]
        elif line_format == 'S3':
            return line_contents[4:12]
        else:
            return 'NO_DATA'

    def get_address_of_line(self,line_no):
        """
        get_address_of_line(line_no) -> string
        Get the address information of current line accodring to the line format, 
        return NOT_DATA for no data line(S0/S4/S5/S6/S7.....)
        """
        line_format = self.get_current_line_format(line_no)
        if line_format == 'S1':
            return self.all_lines[line_no][4:8]
        elif line_format == 'S2':
            return self.all_lines[line_no][4:10]
        elif line_format == 'S3':
            return self.all_lines[line_no][4:12]
        else:
            return 'NO_DATA'

    def get_checksum_of_line(self,line_no):
        """
        get_checksum_of_line(line_no) -> string
        Get the checksum information of current line accodring to the line format, r
        eturn NOT_DATA for no data line(S0/S4/S5/S6/S7.....)
        """
        line_format = self.get_current_line_format(line_no)
        if line_format == 'S1' or line_format == 'S2' or line_format == 'S3':
            return self.all_lines[line_no][-3:-1]
        else:
            return 'NO_DATA'

    def get_data_of_line_by_content(self, line_contents):
        """
        get_data_of_line_by_content(line_contents) -> string
        Get the data information of current line by content accodring to the line format, 
        return NOT_DATA for no data line(S0/S4/S5/S6/S7.....)
        """
        line_format = self.get_current_line_format_by_content(line_contents)
        if line_format == 'S1':
            return line_contents[8:-3]
        elif line_format == 'S2':
            return line_contents[10:-3]
        elif line_format == 'S3':
            return line_contents[12:-3]
        else:
            return 'NO_DATA'

    def get_data_of_line(self,line_no):
        """
        get_data_of_line(line_no) -> string
        Get the data information of current line accodring to the line format, 
        return NOT_DATA for no data line(S0/S4/S5/S6/S7.....)
        """
        line_format = self.get_current_line_format(line_no)
        if line_format == 'S1':
            return self.all_lines[line_no][8:-3]
        elif line_format == 'S2':
            return self.all_lines[line_no][10:-3]
        elif line_format == 'S3':
            return self.all_lines[line_no][12:-3]
        else:
            return 'NO_DATA'

    def get_data_no_in_byte(self,line_no):
        """
        get_data_no_in_byte(line_no) -> int
        Count the number of data of current line in byte,
        return 0 for NO_DATA line
        """
        idx = 0
        if self.get_data_of_line(line_no) != 'NO_DATA':
            for c in self.get_data_of_line(line_no):
                idx += 1
            return idx/2
        else:
            return 0

    def get_data_of_line_as_list(self,line_no):
        """
        get_data_of_line_as_list(line_no) -> list
        Get the data of current line in list format(byte element),
        return empty list for NO_DATA line
        """
        if self.get_data_of_line(line_no) != 'NO_DATA':
            datlst=list()
            for idx in range(0,len(self.get_data_of_line(line_no)[::2])):
                datlst.append(self.get_data_of_line(line_no)[::2][idx]+self.get_data_of_line(line_no)[1::2][idx])
        else:
            datlst = []
        return datlst
    
    def split_data_line_into_list(self,data):
        """
        split_data_line_into_list(data) -> list
        Split string into list format
        """
        datlst=list()
        for idx in range(0,len(data[::2])):
            datlst.append(data[::2][idx]+data[1::2][idx])
        return datlst
    
    def get_data_by_address_and_length(self, address, length):
        """
        get_data_by_address_and_length(address, length) -> string
        Get the data by address and length, the address argument must
        be in a hex format(0x780010), and the length means length of bytes
        return 'NO_DATA' if the address or the length is wrong
        """
        fun = lambda x:'0x'+(hex(x).split('x')[-1].strip('L')[::-1]+'00000000')[::-1][-8:]
        step = self.get_data_no_in_byte(1)
        value = self.dict_by_address.get(fun(address))

        # if address is in key list
        if value != None:
            if length <= step:
                return value[:length * 2]
            else:
                retVal = ""
                rows = length / step
                last = length -  rows * step

                # If the input length is too large
                maxLength = (self.get_total_line_numbers() - 2) * step
                if length > maxLength:
                    return 'NO_DATA'

                for i in range(0, rows):
                    retVal += self.dict_by_address.get(fun(address + step * i))

                if last != 0:
                    lastLine = self.dict_by_address.get(fun(address + step * rows))
                    retVal += lastLine[:last * 2]

                return retVal

        else:
            for key in self.dict_by_address.keys():
                dataOffset = address - int(key, 0)
                if dataOffset > 0 and dataOffset < step:
                    retVal = self.get_data_by_address_and_length(int(key, 16), length + dataOffset)
                    if retVal != 'NO_DATA':
                        return retVal[dataOffset * 2:]

            # If the input address is not valid
            return 'NO_DATA'

    def get_data_by_start_and_end_address(self, start_address, end_address):
        """
        get_data_by_start_and_end_address(start_address, end_address) -> string
        Get the data by start address and end_address, the address argument must
        be in a hex format(0x780010)
        return 'NO_DATA' if the address or the length is wrong
        """

        length = end_address - start_address + 1
        if length > 0:
            return self.get_data_by_address_and_length(start_address, length)
        else:
            return 'NO_DATA'

