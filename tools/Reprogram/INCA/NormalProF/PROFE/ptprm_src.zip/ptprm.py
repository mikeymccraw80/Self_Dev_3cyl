
import sys
from ptp_parser.ptp_parser import *

if __name__ == '__main__':
    if len(sys.argv) == 3:
        ptp = ptp_file(sys.argv[1])
        s5_list = list()
        s7_list = list()
        s8_list = list()
        s9_list = list()
        try:
            outfile = file(sys.argv[2],'w')
        except:
            print "Can't create output file...."
            sys.exit(255)   
        for no in range(0,ptp.get_total_line_numbers()):
            if ptp.get_current_line_format(no) == 'S5':
                s5_list.append(no)
            if ptp.get_current_line_format(no) == 'S7':
                s7_list.append(no)
            if ptp.get_current_line_format(no) == 'S8':
                s8_list.append(no)
            if ptp.get_current_line_format(no) == 'S9':
                s9_list.append(no)
        try:
            s5_list.pop()  # pop the last one out
        except:
            pass
        try:
            s7_list.pop()
        except:
            pass
        try:
            s8_list.pop()
        except:
            pass
        try:
            s9_list.pop()
        except:
            pass
        for no in range(0,ptp.get_total_line_numbers()):
            if s5_list.count(no):
                print "ptprm removed line " + str(no)
            elif s7_list.count(no):
                print "ptprm removed line " + str(no)
            elif s8_list.count(no):
                print "ptprm removed line " + str(no)
            elif s9_list.count(no):
                print "ptprm removed line " + str(no)
            else:
                outfile.write(ptp.all_lines[no])
        outfile.close()
    else:
        print "This tool is used to remove the termination from given S19 file"
        print "<Usage> Command infile outfile"
