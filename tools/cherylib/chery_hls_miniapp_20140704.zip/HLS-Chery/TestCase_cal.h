#ifndef __TestCase_cal_H
#define __TestCase_cal_H


//dve
extern const volatile uint16_T VAL_etcPeriod ;
extern const volatile uint16_T VAL_etcDuty ;
extern const volatile uint16_T VAL_etcEnable ;
extern const volatile uint16_T VAL_etcDirection ;
//dio
extern const volatile uint16_T VAL_B_Fan1 ;
extern const volatile uint16_T VAL_B_Fan2 ;
extern const volatile uint16_T VAL_B_Pmp ;
extern const volatile uint16_T VAL_B_MRlyOn ;
extern const volatile uint16_T VAL_B_MIL ;
extern const volatile uint16_T VAL_B_SVS ;
extern const volatile uint16_T VAL_B_AcOn;
extern const volatile uint16_T VAL_B_StaRly ;
extern const volatile uint16_T VAL_B_Vis ;

extern const volatile uint16_T VAL_B_DO_R_LINE ;
extern const volatile uint16_T VAL_B_LsbHtEn ;
extern const volatile uint16_T VAL_B_LsaHtEn ;


//ign
extern const volatile uint16_T VAL_ign_test ;
extern const volatile uint16_T VAL_ign_enable_0 ;
extern const volatile uint16_T VAL_ign_enable_1 ;
extern const volatile uint16_T VAL_ign_enable_2 ;
extern const volatile uint16_T VAL_ign_enable_3;
extern const volatile uint16_T VAL_dwell_time_of_follow_up_sparks ;
extern const volatile uint16_T VAL_break_time_of_follow_up_sparks ;
extern const volatile uint16_T VAL_dwell_time ;
extern const volatile int8_T VAL_ign0_angle ;
extern const volatile int8_T VAL_ign1_angle ;
extern const volatile int8_T VAL_ign2_angle ;
extern const volatile int8_T VAL_ign3_angle;
extern const volatile uint8_T VAL_follow_up_sparks ;
//inj
extern const volatile uint16_T VAL_inj_test ;
extern const volatile uint16_T VAL_inj_enable_0 ;
extern const volatile uint16_T VAL_inj_enable_1 ;
extern const volatile uint16_T VAL_inj_enable_2 ;
extern const volatile uint16_T VAL_inj_enable_3;
extern const volatile uint32_T VAL_inj_time ;
extern const volatile uint16_T VAL_post_inj_time ;
extern const volatile uint8_T VAL_inj_end_angle ;
extern const volatile uint8_T VAL_abort_angle ;
extern const volatile uint8_T VAL_B_post_inj ;
//kva
extern const volatile uint16_T  VAL_instant_fuel_consumption;
//pwm
extern const volatile uint8_T VAL_PerPgv ;
extern const volatile uint16_T VAL_DuCyPgOut;
extern const volatile uint8_T VAL_B_Pg ; 
extern const volatile uint16_T VAL_DyCyPsIn ;
extern const volatile uint8_T VAL_B_CamcRlsIn ;
extern const volatile uint16_T VAL_DyCyPsOut ;
extern const volatile uint8_T VAL_B_CamcRlsOut ;
//sys
extern const volatile uint8_T VAL_B_SW_Pwf ;
extern const volatile uint8_T VAL_B_after_run_end ;


#endif
