

#include "HLS.h"
 
uint16_t HLS_MAP_Value;
bool   HLS_MAP_Status;
uint16_t HLS_OXYGEN_Value;
bool  HLS_OXYGEN_Status;
uint16_t HLS_BATT_Value;
bool  HLS_BATT_Status;
unsigned short Pim;
uint16_t HLS_PBATT_Value;
bool  HLS_PBATT_Status;
uint16_t HLS_TA_Value;
bool  HLS_TA_Status;
uint16_t HLS_ECT_Value;
bool HLS_ECT_Status;
uint16_t HLS_TPS_Value;
bool HLS_TPS_Status;
uint8_t HLS_Filtered_AC_REQUEST_INPUT;
uint8_t HLS_Filtered_AC_PRESSURE_SWITCH;
uint8_t HLS_Filtered_DI_CAM_1;
uint8_t HLS_Filtered_DI_IGN_ON_OFF_SW;
uint8_t HLS_Filtered_DI_HEAD_LAMP;
unsigned char  TpPos_b;//tps=100*0.3922=39.22
unsigned char  Pmap_b;
unsigned char  Tm;//Tm= 200*0.75-48 =102
unsigned char  TmLin; 
unsigned char  Ta;
 uint8_t FCMEnd;
 uint8_t MafTst;
 uint16_t fLc;
 uint16_t fLcAd;
 uint8_t Pmap_b;
 unsigned short       Pmap;
 uint16_t N;
 uint16_t VspRaw;
 int8_t IgaOut;
 uint8_t TaLin;
 uint16_t Tpp;
 uint16_t uLsb;
 uint16_t uLsa;
 uint16_t KmQ1Mil;
 uint8_t Ub_b;
 uint8_t TpPos_b;
 uint16_t uTm;
 uint8_t uTa;
 uint16_t uPmap;
 uint16_t uTps;
 uint16_t Fl;
 uint32_t Ti;
 uint8_t Nstat;
 int16_t dN;
 int16_t dTqLosAd;
 int8_t dIgaKncDyn;
 uint8_t B_Knk;
 uint8_t Ld_b;
 uint16_t fAlt;
 int16_t  dTqIdcP;
 int16_t dTqIdcI;
 int8_t dIgaKnc[4];
 uint16_t FtCntEmis;
 uint16_t FtCntEmisCyl[4];
 int16_t RounFon;
 unsigned short Pam;
 bool                 B_Fan1;
 bool                 B_Fan2;
 bool                 B_AcOn;
 uint16_t tLsbAfFlt;
 int8_t IntLcDwnI;
 uint8_t SsCatDwnM;
 uint8_t MxGrdLsaFit_b;
 uint8_t B_LsaRdy;
 int8_t Acl_b;
 uint16_t TcatInPre;
 uint16_t uTp1;
 uint16_t uTp2;
 uint16_t TpPosDpc;
 int16_t TpPos;
 uint16_t dpcpids;
 uint8_t B_dpcPids;
 uint16_t uPed1;
 uint16_t uPed2;
 uint8_t PedPos_b;
 uint16_t AngCamOvlapAdj;
 uint8_t fctCamOvlapIn_b;
 uint8_t fctCamOvlapOut_b;
 uint16_t DyCyPsIn;
 uint16_t DyCyPsOut;
 uint16_t DuCyPgOut;
 int16_t FlPg;
 uint16_t fPgRatDsr;
 int16_t fPgAdp;
 uint8_t Tam;
 uint8_t StcEtcAdpt;
 uint8_t ScSpr;
 uint8_t ScAntiIce;
 uint8_t ScLrn;
 uint8_t B_LrnSuc;
 uint16_t uTp1Lw;
 uint16_t uTp2Lw;
 uint16_t TpPosNlp;
 uint8_t FrBitsEtsm;
 uint8_t B_FofEtsm;
 uint32_t Tooth_time;
//Freeze_Frame_Elem  DIAG_STATUS_FREEZE_FRAME[3];
//tele_type telem_data;
//uint8_t 	count_DTCs_SID03;
//uint16_t	DTCs_SID03[Sy_Fcmtsize];
//bool	B_DiagInfoClrReq;
//uint8_t 	count_DTCs_SID07;
//uint16_t	DTCs_SID07[SY_FCMTSIZE];

/*the flowing is ISO14230 service 0x31&0x32 */
// uint8_t  SupFlagC0[4];    /* 0xC0  ID Support Flag($C1-$E0) */
// uint8_t  SupFlagE0[4];    /* 0xE0  ID Support Flag($E1-$FF) */
bool     B_Inj0Req;       /* 0xCC  KDS request #1cylinder injector test  */
bool     B_Inj0Stp;       /* 0xCC  KDS stop #1cylinder injector test  */
bool     B_Inj1Req;       /* 0xCD  KDS request #2cylinder injector test */
bool     B_Inj1Stp;       /* 0xCD  KDS stop #2cylinder injector test  */
bool     B_Inj2Req;       /* 0xCE  KDS request #3cylinder injector test  */
bool     B_Inj2Stp;       /* 0xCE  KDS stop #3cylinder injector test  */
bool     B_Inj3Req;       /* 0xCF  KDS request #4cylinder injector test  */
bool     B_Inj3Stp;       /* 0xCF  KDS stop #4cylinder injector test  */
bool     B_FulPReq;       /* 0xD4  KDS demand fuel pump test  */
bool     B_FulPStp;       /* 0xD4  KDS request fuel pump test   */
bool     B_Fan1Req;       /* 0xE5  KDS request low fan test  */
bool     B_Fan1Stp;       /* 0xE5  KDS stop low fan test   */
bool     B_Fan2Req;       /* 0xE6  KDS request low fan test  */
bool     B_Fan2Stp;       /* 0xE6  KDS stop low fan test   */
bool     B_CpgVReq;       /* 0xE8  KDS request canister purge valve test  */
bool     B_CpgVStp;       /* 0xE8  KDS stop canister purge valve test  */
bool     B_MILReq;        /* 0xD5  Tester request MIL work 5S */
bool     B_MILStp;        /* 0xD5  Tester request stop test */
bool     B_SVSReq;        /* 0xD6  Tester request SVS work 5S */
bool     B_SVSStp;        /* 0xD6  Tester request stop test */

uint8_t Gr;
uint8_t Maf_b;
uint16_t             KmQ1;
uint16_t             KmQ65;
signed char              dNDsr;
bool                 B_Fof;

//EOBD_KPAa            Pam;
//CHERY_KPAa             Pim;
//CHERY_DEG_T            Taini;
//CHERY_DEG_T          Tmini;
//EOBD_KPH             Vsp;
//CHERY_AIRFLOW_KGH    Maf ;
//CHERY_Lam            LamDsrLim;
signed char              dNDsr;
//CHERY_RPMa           Nstat;
//CHERY_BPW            Ti_b1;
//CHERY_TEMP_Ta        TexBfCat;
//CHERY_TEMP_Ta        TcatInPre;

//Percent_Plus_Fraction  TpPosl;

/* IUPR part, defined in HLS*/
uint16_t NcDGDM_RM_OFVC_IgnCycleCntr;
uint16_t NcDGDM_RM_Generic_Denom;
uint16_t NcDGDM_RM_ICMD_B1_Numrtr;
uint16_t NcDGDM_RM_ICMD_B1_Denom;
uint16_t NcDGDM_RM_EOSD_B1_S1_Numrtr;
uint16_t NcDGDM_RM_EOSD_B1_S1_Denom;
uint16_t NcDGDM_RM_EOSD_B1_S2_Numrtr;
uint16_t NcDGDM_RM_EOSD_B1_S2_Denom;
uint16_t NcDGDM_RM_VVT1_Numrtr;
uint16_t NcDGDM_RM_VVT1_Denom;
uint16_t NcDGDM_RM_VVT2_Numrtr;
uint16_t NcDGDM_RM_VVT2_Denom;

/*VCPC*/
//uint16_t angle_crank_cam_inlet;
//uint16_t angle_crank_cam_outlet;

//ETC
//etc_signals etc_sig;

//soh fault
//Soh_Fault_Log_Type soh_fault;

#define START_SECTION_static_volatile_SlowRam_32bit
#include "PRAGMA_CHERY.h"
uint32_t hlsbss_test0;
uint32_t hlsbss_test1;
uint32_t hlsbss_test2;
#define STOP_SECTION_static_volatile_SlowRam_32bit
#include "PRAGMA_CHERY.h"

#define START_SECTION_static_nonvolatile_SlowRam_32bit
#include "PRAGMA_CHERY.h"
uint32_t nvram_test0;
uint32_t nvram_test1;
uint32_t  nvram_test2;
#define STOP_SECTION_static_nonvolatile_SlowRam_32bit
#include "PRAGMA_CHERY.h"
uint16_T C10ms_100ms[20];

uint32_T taskcount[30];

uint8_T flagwhile[30];



void HLS_Task_1ms(void)

{
	taskcount[0]++;
	if(flagwhile[0] == 1)
		while(1){}
	
	
	if( sys_status.B_Pwf == 1)
		nvram_test0 = 22;
		
		ADC_test_1ms();
}

/* Call back function for 2ms task */
void HLS_Task_2ms(void)
{
	taskcount[1]++;
		if(flagwhile[1] == 1)
		while(1){}
}

void HLS_Task_5ms(void)
{
 
	taskcount[2]++;
		if(flagwhile[2] == 1)
		while(1){}
}

/* Call back function for 10ms task */
void HLS_Task_10ms(void)
{
	
	taskcount[3]++;
		if(flagwhile[3] == 1)
		while(1){}
	ADC_test_10ms();
	DI_test_10ms();
	epm_test_10ms();
	C10ms_100ms[0]++;
	
	if(C10ms_100ms[0]>=65535)
 		C10ms_100ms[0] = 65534;
	//DO_test_10ms();
	
	//PWM_test_10ms();
	
		
}
Soh_Fault_Log_Type soh_test;
/* Call back function for 20ms task */
void HLS_Task_20ms(void)
{
	taskcount[4]++;
		if(flagwhile[4] == 1)
		while(1){}
	
}
/* Call back function for 50ms task */
 void HLS_Task_50ms(void)
{
	taskcount[5]++;
		if(flagwhile[5] == 1)
		while(1){}
}
/* Call back function for 100ms task */

 void HLS_Task_100ms(void)
{
	
	taskcount[6]++;
		if(flagwhile[6] == 1)
		while(1){}
	
	if(C10ms_100ms[0] == 0)
		{
			C10ms_100ms[1]++;
			}
			
		if(C10ms_100ms[1] == 1)
			LLD_do_table[LLD_DO_FAN2].value = !LLD_do_table[LLD_DO_FAN2].value;
 
 
 
 
 
 
}
/* Call back function for 200ms task */

void HLS_Task_200ms(void)
{
	taskcount[7]++;
		if(flagwhile[7] == 1)
		while(1){}
}
/* Call back function for 1000ms task */
void HLS_Task_1000ms(void)
{


	taskcount[8]++;
		if(flagwhile[8] == 1)
		while(1){}
}

void HLS_afterrun(void)
{


	taskcount[9]++;
		if(flagwhile[9] == 1)
		while(1){}
}

/*HLS initialization function.*/
void HLS_ini(void)
{

	taskcount[10]++;
		if(flagwhile[10] == 1)
		while(1){}
  C10ms_100ms[0] = 0;
}

/*HLS initialization function*/
void HLS_ini2(void)
{
	taskcount[11]++;
		if(flagwhile[11] == 1)
		while(1){}
	ADC_test_ini2();
}
/*will be called after _ini() at ECU power on, and at engine stall*/
void HLS_inisyn(void)
{
	taskcount[12]++;
		if(flagwhile[12] == 1)
		while(1){}
	ign_test_inisyn();
	inj_test_inisyn();
	epm_test_inisyn();
}

/*will be called when the synch is lost/reset, this is an event trigged function call*/
void HLS_rstsyn(void)
{
	taskcount[13]++;
		if(flagwhile[13] == 1)
		while(1){}
	HLS_inisyn();
}
/*will be called when the first Synchronization (first gap) is confirmed, this is an event trigged function call*/
void HLS_firstsyn(void)
{
	taskcount[14]++;
		if(flagwhile[14] == 1)
		while(1){}
	
}
uint32_T Result_Flt;
uint32_T Result_Flt1;
uint32_T Result_Flt2;
uint32_T Result_Flt3;
uint16_T *PtrHwrd;
uint16_T *PtrLwrd;
uint16_T Temp2; 
uint16_T Temp4;
uint16_T Temp5;
uint16_T Temp6;
int32_T local_Switch1;
int32_T local_Switch2;
uint16_T frmv;
int8_T test;
/*will be called for every segment (at Software reference mark)*/
void HLS_syn(void)
{
	taskcount[15]++;
		if(flagwhile[15] == 1)
		while(1){}
	misfire_test_syn();
	
	inj_test_syn();
	ign_test_syn();
	
	B_syn_update = 1;
	
	PtrHwrd = &Temp5;
	
	PtrLwrd = &Temp6;
	


   Result_Flt = (uint32_T)((((uint32_T)(*PtrHwrd))<<16 )+ ((uint32_T)(*PtrLwrd))) + (uint32_T)(((uint32_T)Temp2 - (uint32_T)(*PtrHwrd))*(uint32_T)Temp4) ;

	
	Result_Flt1 = (uint32_T)(((uint32_T)(*PtrHwrd))<<16);
 Result_Flt2 = Result_Flt1 + ((uint32_T)(*PtrLwrd)) ;
Result_Flt3 = Result_Flt2  + (uint32_T)(((uint32_T)Temp2 - (uint32_T)(*PtrHwrd))*(uint32_T)Temp4);

	
local_Switch1	  = (int32_T)((int16_T)32767U - (int16_T)frmv) * (int32_T)(uint8_T)test;

 local_Switch2 = (int32_T)((int32_T)32768U - (int32_T)frmv) * (int32_T)(uint8_T)test;
	
	
	
	
}
	
/*will be called on each 
}falling edge of the CAM signal*/
void HLS_ph1(void)
{

	taskcount[16]++;
	if(flagwhile[16] == 1)
		while(1){}




}

/*will be called on each falling edge of the CAM signal*/
 void HLS_ph2(void)
{

	taskcount[17]++;
		if(flagwhile[17] == 1)
		while(1){}
}
/* will be called at the falling edge of every crank tooth */
 void HLS_tooth_interrupt(void)
{
	taskcount[18]++;
		if(flagwhile[18] == 1)
		while(1){}
   toot_test_interrupt();
} 

