#include "HLS.h"

//dve
const volatile uint16_T VAL_etcPeriod = 500;
const volatile uint16_T VAL_etcDuty = 10000;
const volatile uint16_T VAL_etcEnable = 0;
const volatile uint16_T VAL_etcDirection = 0;
//dio
const volatile uint16_T VAL_B_Fan1 = 0;
const volatile uint16_T VAL_B_Fan2 = 0;
const volatile uint16_T VAL_B_Pmp = 0;
const volatile uint16_T VAL_B_MRlyOn = 0;
const volatile uint16_T VAL_B_MIL = 0;
const volatile uint16_T VAL_B_SVS = 0;
const volatile uint16_T VAL_B_AcOn = 0;
const volatile uint16_T VAL_B_StaRly = 0;
const volatile uint16_T VAL_B_Vis = 0;

const volatile uint16_T VAL_B_DO_R_LINE = 0;
const volatile uint16_T VAL_B_LsbHtEn = 0;
const volatile uint16_T VAL_B_LsaHtEn = 0;


//ign
const volatile uint16_T VAL_ign_test = 0;
const volatile uint16_T VAL_ign_enable_0 = 1;
const volatile uint16_T VAL_ign_enable_1 = 1;
const volatile uint16_T VAL_ign_enable_2 = 1;
const volatile uint16_T VAL_ign_enable_3 = 1;
const volatile uint16_T VAL_dwell_time_of_follow_up_sparks = 0;
const volatile uint16_T VAL_break_time_of_follow_up_sparks = 0;
const volatile uint16_T VAL_dwell_time = 2500;
const volatile int8_T VAL_ign0_angle = 0;
const volatile int8_T VAL_ign1_angle = 0;
const volatile int8_T VAL_ign2_angle = 0;
const volatile int8_T VAL_ign3_angle = 0;
const volatile uint8_T VAL_follow_up_sparks = 0;
//inj
const volatile uint16_T VAL_inj_test = 0;
const volatile uint16_T VAL_inj_enable_0 = 1;
const volatile uint16_T VAL_inj_enable_1 = 1;
const volatile uint16_T VAL_inj_enable_2 = 1;
const volatile uint16_T VAL_inj_enable_3 = 1;
const volatile uint32_T VAL_inj_time = 3000;
const volatile uint16_T VAL_post_inj_time = 0;
const volatile uint8_T VAL_inj_end_angle = 127;
const volatile uint8_T VAL_abort_angle = 20;
const volatile uint8_T VAL_B_post_inj = 0;
//kva
const volatile uint16_T  VAL_instant_fuel_consumption = 10;
//pwm
const volatile uint8_T VAL_PerPgv = 10;
const volatile uint16_T VAL_DuCyPgOut = 32768;
const volatile uint8_T VAL_B_Pg = 1; 
const volatile uint16_T VAL_DyCyPsIn = 32768;
const volatile uint8_T VAL_B_CamcRlsIn =1;
const volatile uint16_T VAL_DyCyPsOut = 17628;
const volatile uint8_T VAL_B_CamcRlsOut =1;







//sys
const volatile uint8_T VAL_B_SW_Pwf = 0;
const volatile uint8_T VAL_B_after_run_end = 0;

