/* chery requirement*/
#include "hls.h"
const uint16_t VAL_uTpsMx;
const uint16_t VAL_uTpsMn;
const uint16_t VAL_uTmMx;
const uint16_t VAL_uTmMn;
const uint16_t VAL_uTaMx;
const uint16_t VAL_uTaMn;
const uint16_t VAL_uPmapMx;
const uint16_t VAL_uPmapMn;
const uint16_t VAL_uLsbMx;
const uint16_t VAL_uLsbMn;
const uint8_t  VAL_LmDgFofDly;

/* IAC calibration */
const uint8_t VAL_StepPosMx;
const uint8_t VAL_dNStepLrn;

const uint8_t VAL_TsStPos;
