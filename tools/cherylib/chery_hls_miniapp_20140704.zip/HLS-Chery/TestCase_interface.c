/* *******************************************************************************
    Chery  all rights reserved
    Filename:       interface-test.c
    Create Date:    2013.6.2
    Create By:      GUO SHENG
    Reference By:
    Description: 
    test  interface    
    
    Revision History:
    Date                Author      CQ CR Number    Description
    2013.6.7                                        First create


******************************************************************************* */
#define DELPHI

#ifdef XXXXX
	#include "pta_inf.h" 
	#include "CIL.h"
	#include "include.h"
#endif


#ifdef DELPHI

	#include "HLS.h"
	#include "TestCase_cal.h"
	
	
#define 	LLD_ATD_Toil 0
#define LLD_DI_AC_PRESSURE_SWITCH1 0
#define LLD_DI_AC_PRESSURE_SWITCH2 0
#define LLD_DI_BRAKE_PEDAL_SWITCH 0
#define LLD_DI_CAM_2 0
#define  LLD_DO_O2_HEATER_1 0
#define  LLD_DO_O2_HEATER_2 0
	
	
#endif

/*
ADC
*/
uint16_T uAdcTp1_Ini2;
uint16_T uAdcTp1_1ms;
uint16_T uAdcTp2_Ini2;
uint16_T uAdcTp2_1ms;
uint16_T uAdcLsb_Ini2;
uint16_T uAdcLsb_10ms;
uint16_T uAdcLsa_Ini2;
uint16_T uAdcLsa_10ms;
uint16_T uAdcMap_Ini2;
uint16_T uAdcMap_1ms;
uint16_T uAdcUb_Ini2;
uint16_T uAdcUb_10ms;
uint16_T uAdcTa_Ini2;
uint16_T uAdcTa_10ms;
uint16_T uAdcTm_Ini2;
uint16_T uAdcTm_10ms;
uint16_T uAdcToil_Ini2;
uint16_T uAdcToil_10ms;
uint16_T uAdcPed1_Ini2;
uint16_T uAdcPed1_10ms;
uint16_T uAdcped2_Ini2;
uint16_T uAdcped2_10ms;
uint16_T uAdcAcTmp_Ini2;
uint16_T uAdcAcTmp_10ms;
uint16_T uAdcAcPrs_Ini2;
uint16_T uAdcAcPrs_10ms;
uint16_T uAdcMainRly_Ini2;
uint16_T uAdcMainRly_10ms;
uint16_T uAdcBrkLgt_Ini2;
uint16_T uAdcBrkLgt_10ms;
uint16_T B_KeyOnini;
void ADC_test_ini2(void)
{
  uAdcTp1_Ini2 = LLD_atd_input_table[LLD_ATD_THROTTLE_1].LLD_atd_val;
	uAdcTp2_Ini2 = LLD_atd_input_table[LLD_ATD_THROTTLE_2].LLD_atd_val;
	uAdcLsb_Ini2 = LLD_atd_input_table[LLD_ATD_OXYGEN_SENSOR_1].LLD_atd_val;
	uAdcLsa_Ini2 = LLD_atd_input_table[LLD_ATD_OXYGEN_SENSOR_2].LLD_atd_val;
	uAdcMap_Ini2 = LLD_atd_input_table[LLD_ATD_MAP].LLD_atd_val;
	uAdcUb_Ini2 = LLD_atd_input_table[LLD_ATD_VBATT_SW].LLD_atd_val;
  uAdcTa_Ini2 = LLD_atd_input_table[LLD_ATD_TA].LLD_atd_val;
  uAdcTm_Ini2 = LLD_atd_input_table[LLD_ATD_ECT].LLD_atd_val;
  uAdcToil_Ini2 = LLD_atd_input_table[LLD_ATD_Toil].LLD_atd_val;
  uAdcPed1_Ini2 = LLD_atd_input_table[LLD_ATD_PEDAL_1].LLD_atd_val;
  uAdcped2_Ini2 = LLD_atd_input_table[LLD_ATD_PEDAL_2].LLD_atd_val;
  uAdcAcTmp_Ini2 = LLD_atd_input_table[LLD_ATD_FRONT_EVAP_TEMP].LLD_atd_val;
  uAdcAcPrs_Ini2 = LLD_atd_input_table[LLD_ATD_AC_PRESSURE].LLD_atd_val;
  uAdcMainRly_Ini2 = LLD_atd_input_table[LLD_ATD_BATTERY_1].LLD_atd_val;
  uAdcBrkLgt_Ini2 = LLD_atd_input_table[LLD_ATD_BRAKE_LAMP].LLD_atd_val;
  B_KeyOnini = LLD_di_table[LLD_DI_IGN_ON_OFF_SW].value;
}

void ADC_test_1ms(void)
{ 
	uAdcTp1_1ms = LLD_atd_input_table[LLD_ATD_THROTTLE_1].LLD_atd_val;
	uAdcTp2_1ms = LLD_atd_input_table[LLD_ATD_THROTTLE_2].LLD_atd_val;
	uAdcMap_1ms = LLD_atd_input_table[LLD_ATD_MAP].LLD_atd_val;
	
}

void ADC_test_10ms(void)
{
 	uAdcLsb_10ms  = LLD_atd_input_table[LLD_ATD_OXYGEN_SENSOR_1].LLD_atd_val;
	uAdcLsa_10ms = LLD_atd_input_table[LLD_ATD_OXYGEN_SENSOR_2].LLD_atd_val;
 	uAdcUb_10ms = LLD_atd_input_table[LLD_ATD_VBATT_SW].LLD_atd_val;
  uAdcTa_10ms = LLD_atd_input_table[LLD_ATD_TA].LLD_atd_val;
  uAdcTm_10ms = LLD_atd_input_table[LLD_ATD_ECT].LLD_atd_val;
  uAdcToil_10ms = LLD_atd_input_table[LLD_ATD_Toil].LLD_atd_val;
  uAdcPed1_10ms = LLD_atd_input_table[LLD_ATD_PEDAL_1].LLD_atd_val;
  uAdcped2_10ms = LLD_atd_input_table[LLD_ATD_PEDAL_2].LLD_atd_val;
  uAdcAcTmp_10ms = LLD_atd_input_table[LLD_ATD_FRONT_EVAP_TEMP].LLD_atd_val;
  uAdcAcPrs_10ms = LLD_atd_input_table[LLD_ATD_AC_PRESSURE].LLD_atd_val;
	uAdcMainRly_10ms = LLD_atd_input_table[LLD_ATD_BATTERY_1].LLD_atd_val;
  uAdcBrkLgt_10ms = LLD_atd_input_table[LLD_ATD_BRAKE_LAMP].LLD_atd_val;
  
	Tm = uAdcTm_10ms;


}

/*
AVFZ
*/

uint16_T  dtVspTooth;
void avfz_test_10ms(void)
{
	dtVspTooth = veh_spd_sig.period;
	
}





/*
CAN
*/


/*
DIAG
*/

#ifdef UAES
uint8_T B_diag_crs_complet;//1 *
uint8_T E_diag_crs;
uint8_T B_diag_cas1_complet;//2 *
uint8_T E_diag_cas1;
uint8_T B_diag_cas2_complet;//3 *
uint8_T E_diag_cas2;
uint8_T B_diag_ev1_complet;//4
uint8_T E_diag_err_ev1;
uint8_T E_diag_PsSCB_ev1;
uint8_T E_diag_PsSCG_ev1;
uint8_T E_diag_PsOL_ev1;
 
uint8_T B_diag_ev2_complet;//5
uint8_T E_diag_err_ev2;
uint8_T E_diag_PsSCB_ev2;
uint8_T E_diag_PsSCG_ev2;
uint8_T E_diag_PsOL_ev2;
uint8_T B_diag_ev3_complet;//6
uint8_T E_diag_err_ev3;
uint8_T E_diag_PsSCB_ev3;
uint8_T E_diag_PsSCG_ev3;
uint8_T E_diag_PsOL_ev3;
uint8_T B_diag_ev4_complet;//7
uint8_T E_diag_err_ev4;
uint8_T E_diag_PsSCB_ev4;
uint8_T E_diag_PsSCG_ev4;
uint8_T E_diag_PsOL_ev4;
uint8_T B_diag_cpv_complet;//8
uint8_T E_diag_err_cpv;
uint8_T E_diag_PsSCB_cpv;
uint8_T E_diag_PsSCG_cpv;
uint8_T E_diag_PsOL_cpv;
uint8_T B_diag_kose_complet;//9
uint8_T E_diag_err_kose;
uint8_T E_diag_PsSCB_kose;
uint8_T E_diag_PsSCG_kose;
uint8_T E_diag_PsOL_kose;
uint8_T B_diag_ekp_complet;//10
uint8_T E_diag_err_ekp;
uint8_T E_diag_PsSCB_ekp;
uint8_T E_diag_PsSCG_ekp;
uint8_T E_diag_PsOL_ekp;
uint8_T B_diag_lfs1_complet1;//11
uint8_T E_diag_err_lfs1;
uint8_T E_diag_PsSCB_lfs1;
uint8_T E_diag_PsSCG_lfs1;
uint8_T E_diag_PsOL_lfs1;
uint8_T B_diag_lfs2_complet;///12
uint8_T E_diag_err_lfs2;
uint8_T E_diag_PsSCB_lfs2;
uint8_T E_diag_PsSCG_lfs2;
uint8_T E_diag_PsOL_lfs2;
uint8_T B_diag_mile_complet;//13
uint8_T E_diag_err_mile;
uint8_T E_diag_PsSCB_mile;
uint8_T E_diag_PsSCG_mile;
uint8_T E_diag_PsOL_mile;
uint8_T B_diag_hsve_complet;//14
uint8_T E_diag_err_hsve;
uint8_T E_diag_PsSCB_hsve;
uint8_T E_diag_PsSCG_hsve;
uint8_T E_diag_PsOL_hsve;
uint8_T B_diag_hshe_complet;//15
uint8_T E_diag_err_hshe;
uint8_T E_diag_PsSCB_hshe;
uint8_T E_diag_PsSCG_hshe;
uint8_T E_diag_PsOL_hshe;
uint8_T B_diag_ks_complet;//16 *
uint8_T E_diag_ks;
uint8_T B_diag_dve_complet;//17 **
uint8_T E_diag_err_dve;
uint8_T E_diag_PsShtC_dve;
uint8_T E_diag_PsOtc_dve;
uint8_T E_diag_PsSig_dve;
uint8_T E_diag_PsOL_dve;
uint8_T B_diag_su_complet;//18
uint8_T E_diag_err_su;
uint8_T E_diag_PsSCB_su;
uint8_T E_diag_PsSCG_su;
uint8_T E_diag_PsOL_su;
uint8_T B_diag_vvti_complet;//19
uint8_T E_diag_err_vvti;
uint8_T E_diag_PsSCB_vvti;
uint8_T E_diag_PsSCG_vvti;
uint8_T E_diag_PsOL_vvti;
uint8_T B_diag_vvto_complet;//20
uint8_T E_diag_err_vvto;
uint8_T E_diag_PsSCB_vvto;
uint8_T E_diag_PsSCG_vvto;
uint8_T E_diag_PsOL_vvto;
void diag_test_10ms(void)
{
	//1*
   B_diag_crs_complet = CIL_DiagComplet.B_diag_crs;
   E_diag_crs = CIL_DiagGetErr.B_diag_err_crs;   
  //2*
  B_diag_cas1_complet = CIL_DiagComplet.B_diag_cas1;
  E_diag_cas1 = CIL_DiagGetErr.B_diag_err_cas1;  
  //3*
  B_diag_cas2_complet = CIL_DiagComplet.B_diag_cas2;
  E_diag_cas2 = CIL_DiagGetErr.B_diag_err_cas2;
  //4
  B_diag_ev1_complet = CIL_DiagComplet.B_diag_ev1;
  E_diag_err_ev1 = CIL_DiagGetErr.B_diag_err_ev1;
  E_diag_PsSCB_ev1 = CIL_DiagGetErr.Diag_Ev1_Status.B_diag_PsSCB;
  E_diag_PsSCG_ev1 = CIL_DiagGetErr.Diag_Ev1_Status.B_diag_PsSCG;
  E_diag_PsOL_ev1 = CIL_DiagGetErr.Diag_Ev1_Status.B_diag_PsOL;  
  //5
  B_diag_ev2_complet = CIL_DiagComplet.B_diag_ev2;
  E_diag_err_ev2 = CIL_DiagGetErr.B_diag_err_ev2;
  E_diag_PsSCB_ev2 = CIL_DiagGetErr.Diag_Ev2_Status.B_diag_PsSCB;
  E_diag_PsSCG_ev2 = CIL_DiagGetErr.Diag_Ev2_Status.B_diag_PsSCG;
  E_diag_PsOL_ev2 = CIL_DiagGetErr.Diag_Ev2_Status.B_diag_PsOL;  
  
  
  //6
  B_diag_ev3_complet = CIL_DiagComplet.B_diag_ev3;
  E_diag_err_ev3 = CIL_DiagGetErr.B_diag_err_ev3;
  E_diag_PsSCB_ev3 = CIL_DiagGetErr.Diag_Ev3_Status.B_diag_PsSCB;
  E_diag_PsSCG_ev3 = CIL_DiagGetErr.Diag_Ev3_Status.B_diag_PsSCG;
  E_diag_PsOL_ev3 = CIL_DiagGetErr.Diag_Ev3_Status.B_diag_PsOL;    
  
  //7
  B_diag_ev4_complet = CIL_DiagComplet.B_diag_ev4;
  E_diag_err_ev4 = CIL_DiagGetErr.B_diag_err_ev4;
  E_diag_PsSCB_ev4 = CIL_DiagGetErr.Diag_Ev4_Status.B_diag_PsSCB;
  E_diag_PsSCG_ev4 = CIL_DiagGetErr.Diag_Ev4_Status.B_diag_PsSCG;
  E_diag_PsOL_ev4 = CIL_DiagGetErr.Diag_Ev4_Status.B_diag_PsOL;    
  
  //8
  B_diag_cpv_complet = CIL_DiagComplet.B_diag_cpv;
  E_diag_err_cpv = CIL_DiagGetErr.B_diag_err_cpv;
  E_diag_PsSCB_cpv = CIL_DiagGetErr.Diag_Cpv_Status.B_diag_PsSCB;
  E_diag_PsSCG_cpv = CIL_DiagGetErr.Diag_Cpv_Status.B_diag_PsSCG;
  E_diag_PsOL_cpv = CIL_DiagGetErr.Diag_Cpv_Status.B_diag_PsOL;   
  
  
  
  //9
  B_diag_kose_complet = CIL_DiagComplet.B_diag_kose;
  E_diag_err_kose = CIL_DiagGetErr.B_diag_err_kose;
  E_diag_PsSCB_kose = CIL_DiagGetErr.Diag_Kose_Status.B_diag_PsSCB;
  E_diag_PsSCG_kose = CIL_DiagGetErr.Diag_Kose_Status.B_diag_PsSCG;
  E_diag_PsOL_kose = CIL_DiagGetErr.Diag_Kose_Status.B_diag_PsOL;    
  
  
  //10
  B_diag_ekp_complet = CIL_DiagComplet.B_diag_ekp;
  E_diag_err_ekp = CIL_DiagGetErr.B_diag_err_ekp;
  E_diag_PsSCB_ekp = CIL_DiagGetErr.Diag_Ekp_Status.B_diag_PsSCB;
  E_diag_PsSCG_ekp = CIL_DiagGetErr.Diag_Ekp_Status.B_diag_PsSCG;
  E_diag_PsOL_ekp = CIL_DiagGetErr.Diag_Ekp_Status.B_diag_PsOL;    
  
  
  //11
  B_diag_lfs1_complet1 = CIL_DiagComplet.B_diag_lfs1;
  E_diag_err_lfs1 = CIL_DiagGetErr.B_diag_err_lfs1;
  E_diag_PsSCB_lfs1 = CIL_DiagGetErr.Diag_Lfs1_Status.B_diag_PsSCB;
  E_diag_PsSCG_lfs1 = CIL_DiagGetErr.Diag_Lfs1_Status.B_diag_PsSCG;
  E_diag_PsOL_lfs1 = CIL_DiagGetErr.Diag_Lfs1_Status.B_diag_PsOL;    
  
  
  //12
  B_diag_lfs2_complet = CIL_DiagComplet.B_diag_lfs2;
  E_diag_err_lfs2 = CIL_DiagGetErr.B_diag_err_lfs2;
  E_diag_PsSCB_lfs2 = CIL_DiagGetErr.Diag_Lfs2_Status.B_diag_PsSCB;
  E_diag_PsSCG_lfs2 = CIL_DiagGetErr.Diag_Lfs2_Status.B_diag_PsSCG;
  E_diag_PsOL_lfs2 = CIL_DiagGetErr.Diag_Lfs2_Status.B_diag_PsOL;    
 
 
  //13
  B_diag_mile_complet = CIL_DiagComplet.B_diag_mile ;
  E_diag_err_mile = CIL_DiagGetErr.B_diag_err_mile;
  E_diag_PsSCB_mile = CIL_DiagGetErr.Diag_Mile_Status.B_diag_PsSCB;
  E_diag_PsSCG_mile = CIL_DiagGetErr.Diag_Mile_Status.B_diag_PsSCG;
  E_diag_PsOL_mile = CIL_DiagGetErr.Diag_Mile_Status.B_diag_PsOL;    
  
  
  //14
  B_diag_hsve_complet = CIL_DiagComplet.B_diag_hsve;
  E_diag_err_hsve = CIL_DiagGetErr.B_diag_err_hsve;
  E_diag_PsSCB_hsve = CIL_DiagGetErr.Diag_Hsve_Status.B_diag_PsSCB;
  E_diag_PsSCG_hsve = CIL_DiagGetErr.Diag_Hsve_Status.B_diag_PsSCG;
  E_diag_PsOL_hsve = CIL_DiagGetErr.Diag_Hsve_Status.B_diag_PsOL;    
  //15
  B_diag_hshe_complet = CIL_DiagComplet.B_diag_hshe;
  E_diag_err_hshe = CIL_DiagGetErr.B_diag_err_hshe;
  E_diag_PsSCB_hshe = CIL_DiagGetErr.Diag_Hshe_Status.B_diag_PsSCB;
  E_diag_PsSCG_hshe = CIL_DiagGetErr.Diag_Hshe_Status.B_diag_PsSCG;
  E_diag_PsOL_hshe = CIL_DiagGetErr.Diag_Hshe_Status.B_diag_PsOL;    
  
  
  //16*
  B_diag_ks_complet = CIL_DiagComplet.B_diag_ks;
  E_diag_ks = CIL_DiagGetErr.B_diag_err_ks;  
  //17**
  B_diag_dve_complet = CIL_DiagComplet.B_diag_dve;
  E_diag_err_dve = CIL_DiagGetErr.B_diag_err_dve;
	E_diag_PsShtC_dve = CIL_DiagGetErr.Diag_Dve_Status.B_diag_PsShtC;
	E_diag_PsOtc_dve = CIL_DiagGetErr.Diag_Dve_Status.B_diag_PsOtc;
	E_diag_PsSig_dve = CIL_DiagGetErr.Diag_Dve_Status.B_diag_PsSig;
	E_diag_PsOL_dve = CIL_DiagGetErr.Diag_Dve_Status.B_diag_PsOL;
  //18
  B_diag_su_complet = CIL_DiagComplet.B_diag_su;
  E_diag_err_su = CIL_DiagGetErr.B_diag_err_su;
  E_diag_PsSCB_su = CIL_DiagGetErr.Diag_Su_Status.B_diag_PsSCB;
  E_diag_PsSCG_su = CIL_DiagGetErr.Diag_Su_Status.B_diag_PsSCG;
  E_diag_PsOL_su = CIL_DiagGetErr.Diag_Su_Status.B_diag_PsOL;  
  
  //19
  B_diag_vvti_complet = CIL_DiagComplet.B_diag_vvti;
  E_diag_err_vvti = CIL_DiagGetErr.B_diag_err_vvti;
  E_diag_PsSCB_vvti = CIL_DiagGetErr.Diag_Vvti_Status.B_diag_PsSCB;
  E_diag_PsSCG_vvti = CIL_DiagGetErr.Diag_Vvti_Status.B_diag_PsSCG;
  E_diag_PsOL_vvti = CIL_DiagGetErr.Diag_Vvti_Status.B_diag_PsOL;   
  
  
  //20
  B_diag_vvto_complet = CIL_DiagComplet.B_diag_vvto;
  E_diag_err_vvto = CIL_DiagGetErr.B_diag_err_vvto;
  E_diag_PsSCB_vvto = CIL_DiagGetErr.Diag_Vvto_Status.B_diag_PsSCB;
  E_diag_PsSCG_vvto = CIL_DiagGetErr.Diag_Vvto_Status.B_diag_PsSCG;
  E_diag_PsOL_vvto = CIL_DiagGetErr.Diag_Vvto_Status.B_diag_PsOL;    
   
   

	
	
}

#endif


/*
DIO
*/

uint8_T S_AC;
uint8_T S_Psw;
uint8_T S_PAC;
uint8_T B_PhLH;
uint8_T B_PhLH2;
uint8_T B_KeyOn;
uint8_T S_HeadLgt;
uint8_T S_PwrSteer;
uint8_T S_Brk;
uint8_T S_BrkLamp;
uint8_T S_Clt;
uint8_T B_CrankOn;



void DI_test_10ms(void)
{
	S_AC = LLD_di_table[LLD_DI_AC_REQUEST_INPUT].value;
	
	S_Psw = LLD_di_table[LLD_DI_AC_PRESSURE_SWITCH1].value;
	S_PAC = LLD_di_table[LLD_DI_AC_PRESSURE_SWITCH2].value;	
	B_KeyOn = LLD_di_table[LLD_DI_IGN_ON_OFF_SW].value;
	S_HeadLgt = LLD_di_table[LLD_DI_HEAD_LAMP].value;	
	S_PwrSteer = LLD_di_table[LLD_DI_POWER_STEERING].value;
	S_Brk = LLD_di_table[LLD_DI_BRAKE_PEDAL_SWITCH].value;
	
	S_BrkLamp = LLD_di_table[LLD_DI_BRAKE_LAMP].value;//��Ϊadͨ��	
	S_Clt = LLD_di_table[LLD_DI_CLUTCH_TOP].value;	
	B_PhLH = LLD_di_table[LLD_DI_CAM_1].value;
	B_PhLH2 = LLD_di_table[LLD_DI_CAM_2].value; //��
	
	B_CrankOn = LLD_di_table[LLD_DI_CRANK_REQUEST].value;
	
}
 

 

void DO_test_10ms(void)
{	
	
	LLD_do_table[LLD_DO_FAN1].value = VAL_B_Fan1;
	LLD_do_table[LLD_DO_FAN2].value = VAL_B_Fan2;
	LLD_do_table[LLD_DO_FUEL_PUMP].value = VAL_B_Pmp;
	LLD_do_table[LLD_DO_MAIN_RELAY].value = VAL_B_MRlyOn;
	LLD_do_table[LLD_DO_MIL_LAMP].value = VAL_B_MIL;
	LLD_do_table[LLD_DO_SVS_LAMP].value = VAL_B_SVS;
	LLD_do_table[LLD_DO_AC_CLUTCH].value = VAL_B_AcOn;
	LLD_do_table[LLD_DO_START_MOTR_RLY].value = VAL_B_StaRly;
	LLD_do_table[LLD_DO_VIS_SWITCH].value = VAL_B_Vis;
	LLD_do_table[LLD_DO_R_LINE].value = VAL_B_DO_R_LINE;
	
	LLD_do_table[LLD_DO_O2_HEATER_1].value = VAL_B_LsbHtEn;
	LLD_do_table[LLD_DO_O2_HEATER_2].value = VAL_B_LsaHtEn;
	
}

/*
DVE
*/

void dve_test_1ms(void)
{
	etc_sig.etc_freq = VAL_etcPeriod;
	etc_sig.etc_duty = VAL_etcDuty;
	etc_sig.etc_enable = VAL_etcEnable;
	etc_sig.etc_direction = VAL_etcDirection;
}

/*
EPM
*/

uint16_T B_crank_failed_ini;
uint16_T B_crank_no_sync_ini;
uint16_T B_crank_sync_ini;
uint16_T B_crank_pre_sync_ini;
uint16_T B_crank_limp_home_ini;
uint32_T tseg_l_ini;
uint16_T N_ini;
uint8_T toothNum_ini;
uint8_T B_RefMar_ini;

uint16_T B_crank_failed_10ms;
uint16_T B_crank_no_sync_10ms;
uint16_T B_crank_sync_10ms;
uint16_T B_crank_pre_sync_10ms;
uint16_T B_crank_limp_home_10ms;
uint32_T tseg_l_10ms;
uint16_T N_10ms;
uint8_T toothNum_10ms;
uint8_T B_RefMar_10ms;

uint16_T B_cam_failed_ini;
uint16_T B_cam_loss_of_sync_ini;
uint16_T B_cam_limp_home_ini;
uint16_T cam_period_ini;
uint16_T cam_edge_cout_ini;
uint16_T cam_level_ini;


uint16_T B_cam_failed_10ms;
uint16_T B_cam_loss_of_sync_10ms;
uint16_T B_cam_limp_home_10ms;
uint16_T cam_period_10ms;
uint16_T cam_edge_cout_10ms;
uint16_T cam_level_10ms;
uint32_T tootcount;

void epm_test_inisyn(void)
{
	B_crank_failed_ini = crank_sig.crank_status.B_crank_failed;
	B_crank_no_sync_ini = crank_sig.crank_status.B_crank_no_sync;
	B_crank_sync_ini = crank_sig.crank_status.B_crank_sync;
	B_crank_pre_sync_ini = crank_sig.crank_status.B_crank_pre_sync;
	B_crank_limp_home_ini = crank_sig.crank_status.B_crank_limp_home;
	
	tseg_l_ini = crank_sig.segment_time;
	N_ini = crank_sig.engine_rpm;
//	toothNum_ini = crank_sig.TthSeg;
//	B_RefMar_ini = crank_sig.B_RefMrk;
	
		//
		
	// B_cam_failed_ini = cam_sig.status.B_cam_failed;
	// B_cam_loss_of_sync_ini = cam_sig.status.B_cam_loss_of_sync;
	// B_cam_limp_home_ini = cam_sig.status.B_cam_limp_home;
	
	// cam_period_ini = cam_sig.period;
	// cam_edge_cout_ini = cam_sig.edge_count;
	// cam_level_ini = cam_sig.level;
	tootcount =0;
}
void epm_test_10ms(void)
{
	B_crank_failed_10ms = crank_sig.crank_status.B_crank_failed;
	B_crank_no_sync_10ms = crank_sig.crank_status.B_crank_no_sync;
	B_crank_sync_10ms = crank_sig.crank_status.B_crank_sync;
	B_crank_pre_sync_10ms = crank_sig.crank_status.B_crank_pre_sync;
	B_crank_limp_home_10ms = crank_sig.crank_status.B_crank_limp_home;
	
	tseg_l_10ms = crank_sig.segment_time;
	N_10ms = crank_sig.engine_rpm;
	//toothNum_10ms = crank_sig.TthSeg;
	//B_RefMar_10ms = crank_sig.B_RefMrk;
	
 	N = N_10ms;
		//
	// B_cam_failed_10ms = cam_sig.status.B_cam_failed;
	// B_cam_loss_of_sync_10ms = cam_sig.status.B_cam_loss_of_sync;
	// B_cam_limp_home_10ms = cam_sig.status.B_cam_limp_home;
	
	// cam_period_10ms = cam_sig.period;
	// cam_edge_cout_10ms = cam_sig.edge_count;
	// cam_level_10ms = cam_sig.level;
	
}
uint8_T crankflag[10];
void toot_test_interrupt(void)
{
	
	tootcount++;
	if(tootcount == 1)
	{
			crankflag[1] = crank_sig.crank_status.B_crank_pre_sync;
	}
	if(tootcount == 2)
	{
		crankflag[2] = crank_sig.crank_status.B_crank_pre_sync;
	}
	if(tootcount == 3)
	{
		crankflag[3] = crank_sig.crank_status.B_crank_pre_sync;
	}
	
	
}



/*
IGN
*/ 
int8_T ignout0,ignout1,ignout2,ignout3;
int8_T ignout00,ignout01,ignout02,ignout03;
uint16_T syndelay;
uint8_T ignsyncount;

void ign_test_inisyn(void)
{
	ign_enable.B_ign_A = 1;
	ign_enable.B_ign_B = 1;
	ign_enable.B_ign_C = 1;
	ign_enable.B_ign_D = 1;
	ignout0 =0;
	ignout1 =0;
	ignout2 =0;
	ignout3 =0;
	ignout00 = 80;
	ignout01 = 80;
	ignout02 = 80;
	ignout03 = 80;
	
 syndelay = 1;
	ign_sig[0].dwell_time_of_follow_up_sparks = 0;
	ign_sig[0].break_time_of_follow_up_sparks = 0;
	ign_sig[0].dwell_time = 3000;
  ign_sig[0].ign_angle = 0;
  ign_sig[0].follow_up_sparks = 0;
  
  ign_sig[1].dwell_time_of_follow_up_sparks = 0;
	ign_sig[1].break_time_of_follow_up_sparks = 0;
	ign_sig[1].dwell_time = 3000;
  ign_sig[1].ign_angle = 0;
  ign_sig[1].follow_up_sparks = 0;
  
  ign_sig[2].dwell_time_of_follow_up_sparks = 0;
	ign_sig[2].break_time_of_follow_up_sparks = 0;
	ign_sig[2].dwell_time = 3000;
  ign_sig[2].ign_angle = 0;
  ign_sig[2].follow_up_sparks = 0;
  
  ign_sig[3].dwell_time_of_follow_up_sparks = 0;
	ign_sig[3].break_time_of_follow_up_sparks = 0;
	ign_sig[3].dwell_time = 3000;
  ign_sig[3].ign_angle = 0;
  ign_sig[3].follow_up_sparks = 0;
  
 ignsyncount = 0;

}
extern uint8_T cyl;
uint16_T syndelay;
uint8_T ToothNum;
 
void ign_test_syn(void)
{
	
	int i;
	ToothNum = crank_sig.engine_position_tc;
		for (i = 0 ; i<syndelay*10 ;i++)
		 {
		 	i++;
		 
		 	}
	
	if((S_AC == 1) &&(cyl == 0 ) )
	{ 	 	
		ignsyncount++;
	}
 
 
	
	if(ignsyncount == 1)
	{
		ign_sig[0].ign_angle = ignout0;
	}
	else
	{
		ign_sig[0].ign_angle = ignout00;
		ignsyncount = 0;
	}
	  
	
	
	  
	if((S_AC == 1) &&(cyl == 1 ) )
		
	 {	
	 	 ign_sig[1].ign_angle = ignout01;
	 	 
	 	}
	else
	{		
		ign_sig[1].ign_angle = ignout1;
	
		}
		
		
		
		
	if((S_AC == 1) &&(cyl == 2 ) )
	 {	 
	 	ign_sig[2].ign_angle = ignout02;
	 	}
	else
	{		
		ign_sig[2].ign_angle = ignout2;
		}
		
		
		
	if((S_AC == 1) &&(cyl == 3 ) )
	{	  
		ign_sig[3].ign_angle = ignout03;
		}
	else
	{		
	ign_sig[3].ign_angle = ignout3;
	}
	
	
	
	 if(ign_sig[0].dwell_time == 1500)
	 	ign_enable.B_ign_A = 0;
	 	else
	 		ign_enable.B_ign_A =1 ;
	 
	 
	 
	 
	 
	
	if(VAL_ign_test == 1)
	{
		for (i = 0 ; i<VAL_etcPeriod*10 ;i++)
		 {
		 	i++;
		 	}
		
		
		
		ign_enable.B_ign_A = VAL_ign_enable_0;
		ign_enable.B_ign_B = VAL_ign_enable_1;
		ign_enable.B_ign_C = VAL_ign_enable_2;
		ign_enable.B_ign_D = VAL_ign_enable_3;
				
		ign_sig[0].dwell_time_of_follow_up_sparks = VAL_dwell_time_of_follow_up_sparks;
		ign_sig[0].break_time_of_follow_up_sparks = VAL_break_time_of_follow_up_sparks;
		ign_sig[0].dwell_time = VAL_dwell_time;
		
		if(cyl == 0)			
	  	ign_sig[0].ign_angle = VAL_ign0_angle;
	  else
	  	ign_sig[0].ign_angle = 0;
	  ign_sig[0].follow_up_sparks = VAL_follow_up_sparks;
	
		ign_sig[1].dwell_time_of_follow_up_sparks = VAL_dwell_time_of_follow_up_sparks;
		ign_sig[1].break_time_of_follow_up_sparks = VAL_break_time_of_follow_up_sparks;
		ign_sig[1].dwell_time = VAL_dwell_time;
		if(cyl == 1)
	  	ign_sig[1].ign_angle = VAL_ign1_angle;
	  else
	  	ign_sig[1].ign_angle = 0;
	  ign_sig[1].follow_up_sparks = VAL_follow_up_sparks;
  
  
		ign_sig[2].dwell_time_of_follow_up_sparks = VAL_dwell_time_of_follow_up_sparks;
		ign_sig[2].break_time_of_follow_up_sparks = VAL_break_time_of_follow_up_sparks;
		ign_sig[2].dwell_time = VAL_dwell_time;
		if(cyl == 2)
	  	ign_sig[2].ign_angle = VAL_ign2_angle;
	    else
	  	ign_sig[0].ign_angle = 0;
	  ign_sig[2].follow_up_sparks = VAL_follow_up_sparks;
  
  
		ign_sig[3].dwell_time_of_follow_up_sparks = VAL_dwell_time_of_follow_up_sparks;
		ign_sig[3].break_time_of_follow_up_sparks = VAL_break_time_of_follow_up_sparks;
		ign_sig[3].dwell_time = VAL_dwell_time;
		if(cyl == 3)
	  	ign_sig[3].ign_angle = VAL_ign3_angle;
	  else
	  	ign_sig[3].ign_angle = 0;
	  ign_sig[3].follow_up_sparks = VAL_follow_up_sparks;
	}
	
	
}


/*
INJ
*/ 
uint32_T injtimeA;
uint32_T injtimeB;
uint32_T injtimeC;
uint32_T injtimeD;
uint32_T injtimeA0;
uint32_T injtimeB0;
uint32_T injtimeC0;
uint32_T injtimeD0;


uint32_T injtimeA1;
uint32_T injtimeB1;
uint32_T injtimeC1;
uint32_T injtimeD1;

uint8_T B_posinj0;
uint8_T B_posinj1;
uint8_T B_posinj2;
uint8_T B_posinj3;
uint8_T B_posinj01;
uint8_T B_posinj11;
uint8_T B_posinj21;
uint8_T B_posinj31;
uint8_T inj_enable_count;
uint8_T inj_enable_countdiable;
uint8_T inj_enable_countenable;
uint8_T inj_enable_countTotal;
uint8_T inj_enable_falg;
uint8_T count,count1,count2,count3;
void inj_test_inisyn(void)
{
	inj_enable.B_inj_A = 1;
	inj_enable.B_inj_B = 1;
	inj_enable.B_inj_C = 1;	
	inj_enable.B_inj_D = 1;	
	
	inj_sig[0].inj_time = 4000;
	inj_sig[0].post_inj_time = 0;
	inj_sig[0].inj_end_angle = 127;
	inj_sig[0].abort_angle = 20 ;
	inj_sig[0].B_post_inj = 0;
 
	inj_sig[1].inj_time = 4000;
	inj_sig[1].post_inj_time = 0;
	inj_sig[1].inj_end_angle = 127;
	inj_sig[1].abort_angle = 20 ;
	inj_sig[1].B_post_inj = 0;
	
	inj_sig[2].inj_time = 4000;
	inj_sig[2].post_inj_time = 0;
	inj_sig[2].inj_end_angle = 127;
	inj_sig[2].abort_angle = 20 ;
	inj_sig[2].B_post_inj = 0;
	
	
	inj_sig[3].inj_time = 4000;
	inj_sig[3].post_inj_time = 0;
	inj_sig[3].inj_end_angle = 127;
	inj_sig[3].abort_angle = 20 ;
	inj_sig[3].B_post_inj = 0;
	
	injtimeA = 4000;
	injtimeB = 4000;
	injtimeC = 4000;
	injtimeD = 4000;
	injtimeA0 = 2000;
	injtimeB0 = 2000;
	injtimeC0 = 2000;
	injtimeD0 = 2000;
		
}

void inj_test_syn(void)
{
	
	if(VAL_inj_test == 1)
	{
		inj_enable.B_inj_A = VAL_inj_enable_0;
		inj_enable.B_inj_B = VAL_inj_enable_1;
		inj_enable.B_inj_C = VAL_inj_enable_2;	
		inj_enable.B_inj_D = VAL_inj_enable_3;	
		
		inj_sig[0].inj_time = VAL_inj_time;
		inj_sig[0].post_inj_time = VAL_post_inj_time;
		inj_sig[0].inj_end_angle = VAL_inj_end_angle;
		inj_sig[0].abort_angle = VAL_abort_angle ;
		inj_sig[0].B_post_inj = VAL_B_post_inj;
 
 		inj_sig[1].inj_time = VAL_inj_time;
		inj_sig[1].post_inj_time = VAL_post_inj_time;
		inj_sig[1].inj_end_angle = VAL_inj_end_angle;
		inj_sig[1].abort_angle = VAL_abort_angle ;
		inj_sig[1].B_post_inj = VAL_B_post_inj;
 
 		inj_sig[2].inj_time = VAL_inj_time;
		inj_sig[2].post_inj_time = VAL_post_inj_time;
		inj_sig[2].inj_end_angle = VAL_inj_end_angle;
		inj_sig[2].abort_angle = VAL_abort_angle ;
		inj_sig[2].B_post_inj = VAL_B_post_inj;
 
 		inj_sig[3].inj_time = VAL_inj_time;
		inj_sig[3].post_inj_time = VAL_post_inj_time;
		inj_sig[3].inj_end_angle = VAL_inj_end_angle;
		inj_sig[3].abort_angle = VAL_abort_angle ;
		inj_sig[3].B_post_inj = VAL_B_post_inj;
 
 
 
	}
	
  if(First_Syn_Flag==0)
  {
      inj_sig[INJ_CHANNEL_A].inj_time = 40000;
      inj_sig[INJ_CHANNEL_B].inj_time = 40000;
      inj_sig[INJ_CHANNEL_C].inj_time = 40000;
      inj_sig[INJ_CHANNEL_D].inj_time = 40000;
  } 
  else
	{ 
		if(LLD_cyl_num == 0) 
		{	
			inj_sig[INJ_CHANNEL_A].inj_time = injtimeA;
			inj_sig[INJ_CHANNEL_B].B_post_inj = B_posinj1;//
			inj_sig[INJ_CHANNEL_C].B_post_inj = B_posinj2;//
		}	
	//	else
	//	{	
	//		inj_sig[INJ_CHANNEL_A].inj_time = injtimeA0;
	//		inj_sig[INJ_CHANNEL_C].B_post_inj = 0;//
	//		inj_sig[INJ_CHANNEL_D].B_post_inj = 0;//
	//	}
		if(LLD_cyl_num == 1)
		{	
			inj_sig[INJ_CHANNEL_B].inj_time = injtimeB;
			
			inj_sig[INJ_CHANNEL_C].B_post_inj = B_posinj21;///
			inj_sig[INJ_CHANNEL_D].B_post_inj = B_posinj3;///
		}
	//	else
	//	{
	//		inj_sig[INJ_CHANNEL_B].inj_time = injtimeB0;
	//		inj_sig[INJ_CHANNEL_D].B_post_inj = 0;///
	//		inj_sig[INJ_CHANNEL_A].B_post_inj = 0;///
				
				
//		}
		if(LLD_cyl_num == 2)
		{
			inj_sig[INJ_CHANNEL_C].inj_time = injtimeC;
			
			inj_sig[INJ_CHANNEL_D].B_post_inj = B_posinj31;//
			inj_sig[INJ_CHANNEL_A].B_post_inj = B_posinj0;	//		
		}
//		else
	//	{
	//		inj_sig[INJ_CHANNEL_C].inj_time = injtimeC0;
	//		inj_sig[INJ_CHANNEL_A].B_post_inj = 0;//
	//		inj_sig[INJ_CHANNEL_B].B_post_inj = 0;	//	
		
	//	}
		if(LLD_cyl_num == 3)
		{		
			inj_sig[INJ_CHANNEL_D].inj_time = injtimeD;
			
			inj_sig[INJ_CHANNEL_A].B_post_inj = B_posinj01;//
			inj_sig[INJ_CHANNEL_B].B_post_inj = B_posinj11;//		
		
		}
	//	else
	//	{
	//		inj_sig[INJ_CHANNEL_D].inj_time = injtimeD0;
	//		inj_sig[INJ_CHANNEL_B].B_post_inj = 0;//
	//		inj_sig[INJ_CHANNEL_C].B_post_inj = 0;//	
	//		
	//	}
	}
	
	
	
//uint8_T inj_enable_count;
//uint8_T inj_enable_countdiable;
//uint8_T inj_enable_countenable;
//uint8_T inj_enable_falg;
//uint8_T inj_enable_countTotal;
	
	
	if(inj_enable_falg == 1)
	{
		
	 
  	if( (cyl == count)||(cyl == count1)||(cyl == count2)||(cyl == count3) )
			inj_enable.B_inj_A = 0;
		else
			inj_enable.B_inj_A = 1;
				
	
		
	}
	
	
	
	
}


/*
KD
*/
uint16_T KnockIntegrator_a;
uint16_T KnockIntegrator_b;
uint16_T KnockIntegrator_c;
uint16_T KnockIntegrator_d;

uint16_T KnockThreshold_a;
uint16_T KnockThreshold_b;
uint16_T KnockThreshold_c;
uint16_T KnockThreshold_d;

uint8_T KnockFlag_a;
uint8_T KnockFlag_b;
uint8_T KnockFlag_c;
uint8_T KnockFlag_d;

void kd_test_syn(void)
{
//	KnockIntegrator_a = KnockIntegrator[0];
///	KnockIntegrator_b = KnockIntegrator[1];
//	KnockIntegrator_c = KnockIntegrator[2];	
//	KnockIntegrator_d = KnockIntegrator[3];	
	
	//KnockThreshold_a = KnockThreshold[0];
	//KnockThreshold_b = KnockThreshold[1];	
//	KnockThreshold_c = KnockThreshold[2];	
//	KnockThreshold_d = KnockThreshold[3];	
	
//	KnockFlag_a = KnockFlag[0];
//	KnockFlag_b = KnockFlag[1];	
//	KnockFlag_c = KnockFlag[2];	
//	KnockFlag_d = KnockFlag[3];	
	
}


/*
KVA
*/
void kva_test_10ms(void)
{
	
	instant_fuel_consumption = VAL_instant_fuel_consumption;	
}
 
 
 /*
  misfire 
 */
uint8_T cyl;
uint32_T tsyl_l_syn;
uint32_T tsyl_l_10ms;
uint32_T tsyl_l_tooth;
void misfire_test_syn(void)
{
	cyl = LLD_cyl_num;
//	tsyl_l_syn = System_Time;
}
 
void misfire_test_10ms(void)
{
 
	//tsyl_l_10ms = System_Time;
} 


void misfire_test_tooth(void)
{
 
//	tsyl_l_tooth = System_Time;
	
} 

/*
PWM
*/


void PWM_test_10ms(void)
{
	//LLD_pwm_out_table[LLD_PWM_PURGE].period = VAL_PerPgv;
	//LLD_pwm_out_table[LLD_PWM_PURGE].duty = VAL_DuCyPgOut;
	//LLD_pwm_out_table[LLD_PWM_PURGE].B_enable = VAL_B_Pg;

	//LLD_pwm_out_table[LLD_PWM_VVT1].duty = VAL_DyCyPsIn;
	//LLD_pwm_out_table[LLD_PWM_VVT1].B_enable = VAL_B_CamcRlsIn;
	
	//LLD_pwm_out_table[LLD_PWM_VVT2].duty = VAL_DuCyPgOut;
	//LLD_pwm_out_table[LLD_PWM_VVT2].B_enable = VAL_B_CamcRlsOut;

}

void PWM_test_ini(void)
{
	
	LLD_pwm_out_table[LLD_PWM_VVT1].period = 4;
	LLD_pwm_out_table[LLD_PWM_VVT2].period = 4;

}


/*
sys
*/
 
uint8_T B_Pwf;
uint8_T B_after_run_end_abnormal1;
void sys_test_ini(void)
{
	B_Pwf = sys_status.B_Pwf;
	B_after_run_end_abnormal1 = sys_status.B_after_run_end_abnormal;
	
}
void sys_test_10ms(void)
{
	sys_cmd.B_SW_Pwf = VAL_B_SW_Pwf;
	sys_cmd.B_after_run_end = VAL_B_after_run_end;
	
}


/*
task
*/


/*
vvt
*/

uint16_T angle_crank_cam_inlet_a;
uint16_T angle_crank_cam_inlet_b;
uint16_T angle_crank_cam_inlet_c;
uint16_T angle_crank_cam_inlet_d;

uint16_T angle_crank_cam_outlet_a;
uint16_T angle_crank_cam_outlet_b;
uint16_T angle_crank_cam_outlet_c;
uint16_T angle_crank_cam_outlet_d;


void vvt_test_ph1(void)
{
	//angle_crank_cam_inlet_a = angle_crank_cam_inlet[0];
	//angle_crank_cam_inlet_b = angle_crank_cam_inlet[1];
	//angle_crank_cam_inlet_c = angle_crank_cam_inlet[2];	
	//angle_crank_cam_inlet_d = angle_crank_cam_inlet[3];	
}
void vvt_test_ph2(void)
{
//	angle_crank_cam_outlet_a = angle_crank_cam_outlet[0];
//	angle_crank_cam_outlet_b = angle_crank_cam_outlet[1];	
//	angle_crank_cam_outlet_c = angle_crank_cam_outlet[2];	
//	angle_crank_cam_outlet_d = angle_crank_cam_outlet[3];	
}














unsigned char testsequence;
unsigned char testerror[17];
unsigned long testerrorcount[17];
//1
void ETSMRSV_r40ms(void)
{
	testsequence ++;
	if(testsequence != 1)
	{
		testerrorcount[1] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[1] = testsequence;
	}

	
}
//2
void ETSMIST_r40ms()
{
	testsequence ++;
		if(testsequence != 2)
	{
		testerrorcount[2] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[2] = testsequence;
	}
	
}
//3
void ETSMAPV_r40ms()
{
		testsequence ++;
			if(testsequence != 3)
	{
		testerrorcount[3] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[3] = testsequence;
	}
}
//4
void ETSMRES1_r40ms()
{
		testsequence ++;
			if(testsequence != 4)
	{
		testerrorcount[4] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[4] = testsequence;
	}
}
//5
void ETSMN_r40ms()
{
	testsequence ++;
		if(testsequence != 5)
	{
		testerrorcount[5] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[5] = testsequence;
	}
}
//6
void ETSMLD_r40ms()
{
		testsequence ++;
			if(testsequence != 6)
	{
		testerrorcount[6] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[6] = testsequence;
	}
}
//7
void ETSMAFST_r40ms()
{
		testsequence ++;
			if(testsequence != 7)
	{
		testerrorcount[7] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[7] = testsequence;
	}
}
//8
void ETSMRES2_r40ms()
{
		testsequence ++;
			if(testsequence != 8)
	{
		testerrorcount[8] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[8] = testsequence;
	}
}
//9
void ETSMTQP_r40ms()
{
	testsequence ++;
		if(testsequence != 9)
	{
		testerrorcount[9] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[9] = testsequence;
	}
}
//10
void ETSMTQF_r40ms()
{
		testsequence ++;
			if(testsequence != 10)
	{
		testerrorcount[10] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[10] = testsequence;
	}
}
//11
void ETSMIGA_r40ms()
{
	testsequence ++;
		if(testsequence != 11)
	{
		testerrorcount[11] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[11] = testsequence;
	}
}
//12
void ETSMRES3_r40ms()
{
	testsequence ++;
		if(testsequence != 12)
	{
		testerrorcount[12] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[12] = testsequence;
	}
}
//13
void ETSMTQC_r40ms()
{
	testsequence ++;
		if(testsequence != 13)
	{
		testerrorcount[13] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[13] = testsequence;
	}
}
//14
void ETSMTQ_r40ms()
{
	testsequence ++;
		if(testsequence != 14)
	{
		testerrorcount[14] ++;
	}
	if(testsequence == 16)
	{
	 
		testsequence = 0;
	}
	else
	{
		testerror[14] = testsequence;
	}
}
//15
void ETSMMFR_r40ms()
{
		testsequence ++;
			if(testsequence != 15)
	{
		testerrorcount[15] ++;
	}
	if(testsequence == 16)
	{

		testsequence = 0;
	}
	else
	{
		testerror[15] = testsequence;
	}
}
//16
void ETSMRES4_r40ms()
{
		testsequence ++;
			if(testsequence != 16)
	{
		testerrorcount[16] ++;
	}
	if(testsequence == 16)
	{
		testerror[16] = testsequence;
		testsequence = 0;
	}
	else
	{
		testerror[16] = testsequence;
	}
}